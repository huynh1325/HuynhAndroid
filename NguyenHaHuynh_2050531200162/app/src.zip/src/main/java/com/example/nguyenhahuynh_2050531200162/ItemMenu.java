package com.example.nguyenhahuynh_2050531200162;

public class ItemMenu {
    public String tenItem;
    public int icon;

    public ItemMenu(String tenItem, int icon) {
        this.tenItem = tenItem;
        this.icon = icon;
    }
}
